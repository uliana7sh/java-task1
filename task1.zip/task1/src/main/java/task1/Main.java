package task1;

public class Main {
    public static void main (String [] args){
        byte b = 4;
        char c = 'G';
        int i = 89;
        short s = 56;
        float f = 4.7333f;
        double d = 4.35545d;
        long l = 12121;
        System.out.println("byte:" + b + "\n" +
                "char:" + c + "\n" +
                "int:" + i + "\n" +
                "short:" + s + "\n" +
                "float:" + f + "\n" +
                "double:" + d + "\n" +
                "long:" + l + "\n" );






    }
}
